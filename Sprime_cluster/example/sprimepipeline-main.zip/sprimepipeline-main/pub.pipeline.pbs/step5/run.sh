Rscript ../tools/score_summary.r ../step4 match.summary.txt

Rscript ../tools/plot_contour.r match.summary.txt chb.contour
